package com.online.trip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripsummaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripsummaryApplication.class, args);
	}

}
